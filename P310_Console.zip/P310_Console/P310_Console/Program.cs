﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P310_Console
{
    class Program
    {
        static void Main()
        {
            #region Checked
            //sbyte - signed byte (işarəli byte, mənfili müsbətli)
            //checked
            //{
            //    byte age = 255;
            //    age += 3; //overflow 

            //    Console.WriteLine(age);
            //}

            #endregion

            #region Char And StringBuilder
            //char c = 'A';
            //int numberOfA = c;

            //Console.WriteLine(GetAlphabetChar(5));

            //wrong way (method)
            //string word = " ";
            //for(int i = 1; i < 1000000; i++)
            //{
            //    word += "hello ";
            //}

            //right way of adding strings

            //string - 8 defe hell - 32 chars - 

            //StringBuilder sb = new StringBuilder();
            //for (int i = 1; i < 100; i++)
            //{
            //    sb.Append("hell");
            //}

            #endregion

            #region floationg point types
            //float f = 5.5F;
            //double d = 13.23;
            //decimal dec = 123.45M;
            #endregion

            #region Nullable value types

            //int? a = null;
            //bool? boolean = null;

            //string b = "";

            #endregion

            #region Struct
            //Point2D point1 = new Point2D();
            //point1.X = 10;
            //point1.Y = 20;

            //Point3D p3d = new Point3D();
            //p3d.X = 13;
            //p3d.Y = 5;
            //p3d.Z = 2;

            //Console.WriteLine(point1.ToString());
            //Console.WriteLine(p3d.ToString());
            #endregion

            #region Casting and upcasting
            //Point3D point3D = new Point3D();
            //point3D.X = point3D.Y = point3D.Z = 20;

            //Point2D point2D = point3D; //upcasting
            //Point2D point2DNew = new Point2D();

            //Point3D point3DNew = (Point3D)point2D;
            //Console.WriteLine(point3DNew);
            #endregion

            Developer developer = new Developer();
            developer.Firstname = "Eli";
            developer.Lastname = "Eliyev";
            developer.Email = "dev@code.az";
            developer.FavLanguage = "C#";

            Accountant accountant = new Accountant();
            accountant.Firstname = "Veli";
            accountant.Lastname = "Veliyev";
            accountant.Email = "acc@code.az";
            accountant.ACCADegree = "F3";

            Employee employee1 = accountant; //upcasting 

            //Developer dev = (Developer)employee1; //insecure way of downcasting
            //Accountant dev = employee1 as Accountant; //secure way of downcasting (way 1)

            if(employee1 is Developer)
            {
                Console.WriteLine((Developer)employee1);
            }

            else
            {
                Console.WriteLine("false");
            }

            Sum(developer, accountant);

        }

        static string Sum(Employee a, Employee b)
        {
            if (a is Developer)
            {
                Developer dev = (Developer)a;
            }
            else if(a is Accountant)
            {
                Accountant acc = (Accountant)a;
            }
            return a.Firstname + " " + b.Firstname;
        }

        static char GetAlphabetChar(byte position, bool upper = false)
        {
            int startPosition = upper ? 'A' : 'a';

            return (char)(startPosition + position - 1);
        }
    }

    public abstract class Employee
    {
        public string Firstname;
        public string Lastname;
        public string Email;

        public override string ToString()
        {
            return $"{Firstname} {Lastname} {Email}";
        }
    }

    public class Developer : Employee
    {
        public string FavLanguage;

        public override string ToString()
        {
            return $"{base.ToString()} {FavLanguage}";
        }
    }

    public class Accountant : Employee
    {
        public string ACCADegree;
    }

    public class Point2D
    {
        public int X;
        public int Y;

        public override string ToString() => $"{X}, {Y}";
    }

    public class Point3D : Point2D
    {
        public int Z;

        public override string ToString() => $"{X}, {Y}, {Z}";
    }

    //public sealed class A { }

    //public class B : A { }
}
